
package com.ehsan.dns

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val domain = EditText(this)
        domain.hint = "Tunnel Domain"

        val key = EditText(this)
        key.hint = "Public Key"

        val btn = Button(this)
        btn.text = "Save Settings"

        btn.setOnClickListener {
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        layout.addView(domain)
        layout.addView(key)
        layout.addView(btn)
        setContentView(layout)
    }
}
