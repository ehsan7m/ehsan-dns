# ehsan dns
Minimal Android DNSST helper app.

Upload this repo to GitHub and GitHub Actions will build APK automatically.
